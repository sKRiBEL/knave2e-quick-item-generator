export const CATEGORIES = {
    coin: {
        id: "coin",
        label: "KNAVE2E.Coins",
        quantityPerSlot: 500
    }
}