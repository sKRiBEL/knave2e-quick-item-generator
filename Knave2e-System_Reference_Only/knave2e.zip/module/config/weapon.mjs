export const CATEGORIES = {
    melee: {
        id: "melee",
        label: "KNAVE2E.Melee"
    },
    ranged: {
        id: "ranged",
        label: "KNAVE2E.Ranged"
    }
}