export const CATEGORIES = {
    shield: {
        id: "shield",
        label: "KNAVE2E.Shield"
    },
    helmet: {
        id: "helmet",
        label: "KNAVE2E.Helmet"
    },
    gambeson: {
        id: "gambeson",
        label: "KNAVE2E.Gambeson"
    },
    mailShirt: {
        id: "mailShirt",
        label: "KNAVE2E.MailShirt"
    },
    breastplate: {
        id: "breastplate",
        label: "KNAVE2E.Breastplate"
    },
    armPlate: {
        id: "armPlate",
        label: "KNAVE2E.ArmPlate",
    },
    legPlate: {
        id: "legPlate",
        label: "KNAVE2E.LegPlate"
    }
}