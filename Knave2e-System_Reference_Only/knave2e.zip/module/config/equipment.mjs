export const CATEGORIES = {
    equipment: {
        id: "equipment",
        label: "KNAVE2E.Equipment"
    }
}