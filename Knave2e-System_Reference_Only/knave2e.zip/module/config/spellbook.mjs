export const CATEGORIES = {
    spellbook:{
        id: "spellbook",
        label: "KNAVE2E.Spellbook"
    },
    chaosSpellbook:{
        id: "chaosSpellbook",
        label: "KNAVE2E.ChaosSpellbook"
    }
}